CodeForge AI — Brand Assets
===========================
https://codeforgeai.io · a product of Setups Works

Files
-----
codeforge-ai-logo-light.png   Wordmark for light backgrounds (774x186)
codeforge-ai-logo-dark.png    Wordmark for dark backgrounds (774x186)
codeforge-ai-icon.svg         App icon, vector
codeforge-ai-icon-192.png     App icon 192x192
codeforge-ai-icon-512.png     App icon 512x512
codeforge-ai-icon-maskable-512.png  Maskable icon (safe-zone padded)

Colors
------
Brand Blue   #006bff
Deep Navy    #0b3ea8
Foreground   #171717 (light) / #ededed (dark)
Success      #28a948 · Warning #ffae00 · Destructive #e5484d

Usage
-----
- Keep clear space around the mark equal to half the icon height.
- Don't recolor, stretch, add effects, or place on low-contrast imagery.
- Full guidelines: https://codeforgeai.io/design-guidelines
